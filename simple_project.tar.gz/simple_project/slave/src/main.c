#include "uart.h"

int main() {
    // Initialize UART at 115200 baud, 4MHz clock
    uart_init(4000000, 115200);
    
    // Send welcome message
    uart_puts("UART Initialized\r\n");
    
    // Echo received characters
    while(1) {
        char c = uart_getc();
        uart_putc(c);
    }
}
